from flask import render_template, request, jsonify
from . import socketio
from flask_socketio import emit
from .models import Note, ChatMessage
from app import db

@socketio.on('connect')
def handle_connect():
    print("A user connected")

@socketio.on('disconnect')
def handle_disconnect():
    print("A user disconnected")

@socketio.on('note_update')
def handle_note_update(data):
    # Save the new note to the database
    note = Note(content=data['content'])
    db.session.add(note)
    db.session.commit()

    # Retrieve all notes and broadcast them to all clients
    notes = Note.query.order_by(Note.timestamp).all()
    notes_data = [{'id': note.id, 'content': note.content} for note in notes]
    emit('note_update', {'notes': notes_data}, broadcast=True)

@socketio.on('chat_message')
def handle_chat_message(data):
    message = ChatMessage(content=data['message'])
    db.session.add(message)
    db.session.commit()
    emit('chat_message', {'id': message.id, 'content': message.content}, broadcast=True)

# Function to initialize routes
def init_routes(app):
    @app.route('/')
    def index():
        return render_template('index.html')

    @app.route('/notes')
    def notes():
        notes = Note.query.order_by(Note.timestamp).all()
        return render_template('notes.html', notes=notes)

    @app.route('/chat')
    def chat():
        messages = ChatMessage.query.order_by(ChatMessage.timestamp).all()
        return render_template('chat.html', messages=messages)