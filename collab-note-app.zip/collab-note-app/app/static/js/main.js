const socket = io();

// Real-time note updates
const noteEditor = document.getElementById('note-editor');
const updateBtn = document.getElementById('update-btn');
const notesContainer = document.getElementById('notes-container');

if (noteEditor && updateBtn) {
    updateBtn.addEventListener('click', () => {
        const content = noteEditor.value.trim();
        if (content) {
            socket.emit('note_update', { content });
            noteEditor.value = ''; // Clear the editor after sending
        }
    });

    socket.on('note_update', (data) => {
        // Clear the notes container and re-render the updated notes
        notesContainer.innerHTML = '';
        data.notes.forEach(note => {
            const noteElement = document.createElement('div');
            noteElement.className = 'note';
            noteElement.textContent = note.content;
            notesContainer.appendChild(noteElement);
        });
    });
}

// Real-time chat
const chatInput = document.getElementById('chat-input');
const sendBtn = document.getElementById('send-btn');
const chatBox = document.getElementById('chat-box');

if (chatInput && sendBtn && chatBox) {
    sendBtn.addEventListener('click', () => {
        const message = chatInput.value.trim();
        if (message) {
            socket.emit('chat_message', { message });
            chatInput.value = '';
        }
    });

    socket.on('chat_message', (data) => {
        const messageElement = document.createElement('div');
        messageElement.textContent = data.message;
        chatBox.appendChild(messageElement);
        chatBox.scrollTop = chatBox.scrollHeight; // Auto-scroll to the latest message
    });
}