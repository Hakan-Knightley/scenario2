from flask import Flask
from flask_socketio import SocketIO
from flask_sqlalchemy import SQLAlchemy

socketio = SocketIO()
db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'your_secret_key'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'

    db.init_app(app)
    socketio.init_app(app, async_mode='gevent')

    with app.app_context():
        from .routes import init_routes  # Import the init_routes function
        init_routes(app)  # Register the routes
        db.create_all()

    return app